<?php
require_once "script/functions.php";

//set user variables
 $erroremail=''; 
 $userEmail='';  $suss='';


//prevent form from submitting on page load 
if(isset($_POST['SUBSCRIBE'])){
    
    // declare form field variables
$userEmail = trim($_POST['email']);

$emailcount= (strlen ($userEmail ));

//validates user parameters


if(!filter_var($userEmail, FILTER_VALIDATE_EMAIL)){  
    $erroremail = 'Input a valid email';
}

if($emailcount > 1){
    
  $conn=connecTDatabase();          //connect to database  
    try{
    $st = $conn->prepare("INSERT INTO subscribers(email)
      VALUES(:userEmail)");
        
      $st->bindParam(':userEmail', $userEmail);
      $st->execute();
$conn=null; 
      } catch (PDOException $e) {
           print "Database distress. Retry!: " . $e->getMessage() . "<br/>";
           die();
        } 
 $userEmail='';  $suss=''; 
}

   
}


    







?>