<?php

require_once "script/validate.php";

function connecTDatabase(){   //function to connect to database
  //connect to the database
try{
$dsn='mysql:host = localhost; dbname=dinlas';
$user_name = "root";
$user_password = "things";
$conn = new PDO($dsn, $user_name, $user_password );
} catch (PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
  return $conn;
}


function head($title){                //function to set document head
$headcontent=<<<HTML

        <title>$title</title>
	
	<base href="http://127.0.0.1/www.dinlas.com/" /> 
        <meta name="Author" content="Chinyere Uba-Eze." />
        <meta name="robots" content="index,follow">
        <meta http-equiv="content-type" content="text/html charset=UTF-8"/ >
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
       
        
	<script src="js/modernizr.js"></script> 
        
		
	<link href="style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Jura|Julius+Sans+One|Open+Sans|" rel="stylesheet"> 	     
        
	
	
	
HTML;
return $headcontent;
}

function Hedder(){                 //function to set document header
$headercontent=<<<HTML
	   
           
           <div class="balanCER" >

	 
	 <section class="loginCont">
	    
	    <div class="margiN">
	       
             <div class="header">
                    <div class="logoWrapper">
                        <a href="index.php">
                        <img src="images/classLogo.png" alt="company_logo" title="Home" />
		     </a>
                    </div>		    
		    
	    <nav class="navBar1">
			<div class="menuICOn" ></div>
		       <ul class="navCon" style="float: right; margin-bottom: 15px;">
			
                        <li class="TeXt">
			   Become a tutor
			</li>
                        
                        <li>
			   <a href="index.html">
			     <input type="submit" value="LOG IN " class="buttBox"/> 
			   </a>
			</li>
			
			<li>
			   <a href="">
			     <input type="submit" value="SIGN UP" class="buttBox1" style="margin-right: 25px;"/>  
			   </a>
			</li>
						
		       </ul>
		       <p style="clear: both;"></p>
		      </nav>
		     <p style="clear: both;"></p>
	     </div>
	    
           
           
HTML;
return $headercontent;
}


function Footer(){    //function to set footer
$sid=htmlspecialchars($_SERVER["PHP_SELF"]);
$userEmail= '';
$erroremail='';
echo<<< HTML

   
   
   <section class="">
        <div class="futCon">
        
           <div class="futCont">
             <div class="futsubCon">
                <div class="futTitle" style="font-size:11px;">CONNECT WITH US</div>
                <ul>
                  <li>
                    <a href="">
                     <img src="images/facebook.png"/>
                    </a> 
                  </li>
                  <li>
                    <a href="">
                     <img src="images/twitter.png"/>
                    </a> 
                  </li>
                  <li>
                    <a href="">
                     <img src="images/youtube.png"/>
                    </a>
                  </li>
                  <li>
                    <a href="">
                     <img src="images/googleplus.png"/>
                    </a>
                  </li>
                
                </ul>
             </div>
             
             <div class="futsubCon1">
                <div class="futTitle1" style="font-size:11px;">SIGN UP FOR OUR NEWLETTER</div>                   
                  
                    <div class="subForm">
                    <form id="userInfo" action="$sid" method="POST" validate>
                        <table style="width:100%;">
                            <tr style="width:100%;">
                                <td style="width:80%;">
                                <div id="Error2" style="font-size: 12px;color:red;margin-left: 20px;"> $erroremail </div>
                                    <input type="email" name="email" value="$userEmail" placeholder="Email Address" class="subTOmail" required/>
                                </td>
                                <td style="width:20%;">
                                    <input type="submit" name="SUBSCRIBE" class="subTOmailbut" value="Subscribe"/>
                                </td>
                            </tr>
                        </table>
                       <form> 
                    </div>
             </div>
             
           </div>  
             
            <div class="futsubCon2"> <span class="daTe">2019</span> <span class="futText">DiClass</span></div>
             
        </div>
	
	
    </section>
      


		
		
HTML;
}


    
</script>



