<?php

include "script/functions.php";
include "script/validate.php";

?>
<!DOCTYPE HTML>
 <html style="width: 100%; height: 100%;">
    <head>
        <?php echo head('Home Page');     ?> 
   
    </head>
      
    <body style="background-color: #fdfdfd; height: 100%; overflow-x: hidden;">
      
      <!--================================= Start NavBar =============================================-->
                        <header>
	           <?php echo Hedder();      // document header              ?>
                </header>
    
    <!--================================= End NavBar=============================================-->
    
    
     <!--================================= Backdrop starts here =============================================-->
         
	 <div className="BkDrop">
         <img src="images/homepage-img.png" alt="bgimage"/>
        </div>
	  
	    <section class="containerHead" id="home">
	      
	      <div class="sectionWrapper">
		
		<div class="conText">
		 
		 <h3>Learn from an Expert</h3>
		 
		 <p>Engage on one-one-one with a tutor and get hands on traning</p>
		 
		  <div class="inputField">
		   <input type="text" value="" placeholder="What do you want to learn?" class="inputSearch"/>
		   <img src=""/> 
		  </div>
		 
		</div>
		
		      
	      </div> 
		
	    </section>
    
   
	
	
	
   
    <!--================================= Backdrop ends here =============================================-->
    
        
   
     <!--================================= Section =============================================-->
   
    <section class="">
      	
	<div class="conTent">
            <h4> Get personalized recommendations</h4>
	    <div class="stRip" style=" "></div>
            <p class="buText" > Answer a few questions for your top picks and get recommmendations suited to you.</p>
	    <a href=""><p class="buTt"> Get started</p></a> 
	</div>
	
    </section>
   
    <!--================================= section ends =============================================-->
    
                   
	
	
	 <!--================================= Start Footer =============================================-->
            
	    <footer style="clear: both;">
		<?php echo Footer();      // document header              ?>
	    </footer>
	    
    <!--================================= End Footer =============================================-->
	
		
	
	
	
	
</body>

</html>